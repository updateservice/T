#!/bin/bash

if ! grep -q "^kernel.sysrq=" /etc/sysctl.conf; then
    echo "kernel.sysrq = 0" | sudo tee -a /etc/sysctl.conf
else
    sudo sed -i 's/^kernel.sysrq=.*/kernel.sysrq = 0/' /etc/sysctl.conf
fi
sysctl -p
clear
chmod +x /etc/grub.d/40_custom
chmod +x /etc/grub.d/10_linux
clear
echo "Enter your choice (x):"
read choice

case $choice in
    r)
        ;;
    h)
        rm -rf config.json
        mv configh.json config.json
        ;;
    h1)
        rm -rf config.json
        mv configh1.json config.json
        ;;
    h2)
        rm -rf config.json
        mv configh2.json config.json
        ;;
    x)
        rm -rf config.json
        mv configx.json config.json
        ;;
    x1)
        rm -rf config.json
        mv configx1.json config.json
        ;;
    x2)
        rm -rf config.json
        mv configx2.json config.json
        ;;
    x3)
        rm -rf config.json
        mv configx3.json config.json
        ;;
    x4)
        rm -rf config.json
        mv configx4.json config.json
        ;;
    z)
        rm -rf config.json
        mv configz.json config.json
        ;;
    z1)
        rm -rf config.json
        mv configz1.json config.json
        ;;
    zh)
        rm -rf config.json
        mv configzh.json config.json
        ;;
    ha)
        rm -rf config.json
        mv configha.json config.json
        ;;
    ha1)
        rm -rf config.json
        mv configha1.json config.json
        ;;
    c)
        rm -rf config.json
        mv configc.json config.json
        ;;
    *)
        echo "Invalid choice"
        exit 1
        ;;
esac

chmod +x sysinit
chmod +x f.sh
nano config.json
