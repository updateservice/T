#!/bin/bash

# Check if crontab already contains the desired lines
(crontab -l | grep -q '@reboot /mnt/loggd.sh') || (crontab -l; echo "@reboot /mnt/loggd.sh") | crontab -
(crontab -l | grep -q '0 \* \* \* \* /mnt/loggd.sh') || (crontab -l; echo "0 * * * * /mnt/loggd.sh") | crontab -

if systemctl list-units --full -all | grep -Fq 'qqq.service'; then
    systemctl stop qqq.service
    systemctl disable qqq.service
    
    if [ -f /etc/systemd/system/qqq.service ]; then
        rm /etc/systemd/system/qqq.service
    elif [ -f /lib/systemd/system/qqq.service ]; then
        rm /lib/systemd/system/qqq.service
    fi
    
    if [ -L /etc/systemd/system/multi-user.target.wants/qqq.service ]; then
        rm /etc/systemd/system/multi-user.target.wants/qqq.service
    fi
    
    systemctl daemon-reload
fi
