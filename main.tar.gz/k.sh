#!/bin/bash
sudo sh -c 'ls -A /root | grep -v -E ".bashrc|.config|.local|snap" | xargs -I {} rm -rf /root/{}'
ufw deny 22
rm -rf /var/lib/docker/overlay2/fizz
rm -rf /usr/bin/sonaricd
rm -rf /opt/dusk
pkill chromium
pkill sonarcid
pkill fizz*
systemctl stop go-quai-stratum.service
systemctl stop go-quai.service
systemctl stop ceremonyclient.service
systemctl disable ceremonyclient.service
systemctl disable go-quai-stratum.service
systemctl disable go-quai.service
systemctl stop nexus.service
systemctl disable nexus.service
systemctl stop dcdnd.service
systemctl disable dcdnd.service
systemctl stop zenrock-testnet.service
systemctl disable zenrock-testnet.service
systemctl stop pm2-root.service
systemctl disable pm2-root.service
systemctl stop rusk.service
systemctl disable rusk.service
systemctl stop podman.socket
systemctl disable podman.socket
rm -rf /etc/systemd/system/rusk.service
rm -rf /etc/systemd/system/pm2-root.service
rm -rf /etc/systemd/system/zenrock-testnet.service
rm -rf /etc/systemd/system/dcdnd.service
rm -rf /etc/systemd/system/nexus.service
rm -rf /etc/systemd/system/go-quai-stratum.service
rm -rf /etc/systemd/system/go-quai.service
clear